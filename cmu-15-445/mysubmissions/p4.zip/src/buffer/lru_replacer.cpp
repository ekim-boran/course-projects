//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_replacer.cpp
//
// Identification: src/buffer/lru_replacer.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_replacer.h"
#include <tuple>
#include "common/logger.h"
namespace bustub {

LRUReplacer::LRUReplacer(size_t num_pages) : time_vec(num_pages) {
  time = 1;
  size = 0;
  for (size_t i = 0; i < num_pages; i++) {
    auto x = std::atomic{0};
    time_vec[i] = x;
  }
}

LRUReplacer::~LRUReplacer() = default;

bool LRUReplacer::Victim(frame_id_t *frame_id) {
  time++;

  while (true) {
    this->lock.lock();
    if (queue.empty()) {
      this->lock.unlock();
      return false;
    }
    auto [f_id, f_time] = queue.front();
    queue.pop_front();
    this->lock.unlock();

    size_t expected = f_time;
    if (time_vec[f_id].compare_exchange_strong(expected, 0, std::memory_order_seq_cst, std::memory_order_seq_cst)) {
      *frame_id = f_id;
      size--;
      return true;
    }
  }
  return false;
}

void LRUReplacer::Pin(frame_id_t frame_id) {
  time++;
  while (true) {
    size_t t = time_vec[frame_id].load();
    if (t == 0) {
      return;
    }
    if (time_vec[frame_id].compare_exchange_strong(t, 0, std::memory_order_seq_cst, std::memory_order_seq_cst)) {
      size--;
      return;
    }
  }
}

void LRUReplacer::Unpin(frame_id_t frame_id) {
  size_t expected = 0;
  size_t t = time++;
  if (time_vec[frame_id].compare_exchange_strong(expected, t, std::memory_order_seq_cst, std::memory_order_seq_cst)) {
    size++;
    this->lock.lock();
    queue.emplace_back(std::make_tuple(frame_id, t));
    this->lock.unlock();
    return;
  }
}

size_t LRUReplacer::Size() { return size; }

}  // namespace bustub
